#pragma once
#include"Header.h"

class Board;

class Piece
{
protected:
	Position P;
	Board* B;
	COLOR C;
	char sym;

public:	
	Piece(Board*B,Position m_P,COLOR m_C);
	virtual void Draw(int i,int c);
	bool RookCheckEnemy(Board* B, Position S, Position  D);
	void UnDraw();
	bool IsVertical(Position S,Position D );
	bool IsHorizontal(Position S, Position D);
	bool IsDiagonal(Position S, Position D);
	bool IsHorizontalPathClear(Board* B, Position S, Position D);
	bool IsVerticalPathClear(Board* B, Position S, Position D);
	bool IsDiagonalPathClear(Board* B, Position S, Position D);
	COLOR ColorOfPiece();
	bool IsWhitePiece(Board* B, Position S);
	bool IsBlackPiece(Board* B, Position S);
	bool IsNullPtr(Position D);

	bool PawnDiagonal(Board *B,Position S, Position D);
	virtual bool IsLegalMove(Board* B, Position S, Position  D);
	virtual void HighLight_The_Legal_Move(Board*B,Position S);
	void HighLight_The_Dabba(Position D);
	virtual void Un_Highlight_The_Moves(Board* B,Position S, Position E);
	void Un_HighLight(Board *B,Position S);
	virtual bool IsKing(Board* B);


	virtual bool IsThereLegalMove(Board* B, Position S);
	void ChangePosition(Position _P);
	~Piece();
};


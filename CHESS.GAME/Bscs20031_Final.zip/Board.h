#pragma once
#include"piece.h"
#include"Header.h"
class Piece;
class Board
{
private:
	int Dim;	
	int AllMoves[1000][4];
	int MoveCount = 0;
	Piece*** Ps;
public:
	Board();
	void InIt();
	Piece* getpiece(int row,int col);
	void Draw();
	void Play();
	void PrintGrid();
	void PrintFunctions();
	void SelectSource(Position &S, COLOR Turn);
	bool IsLegalSource(Position S, COLOR Source, COLOR Turn);
	void SelectDestination(Position& S, COLOR Turn);
	bool IsLegalDestination(Position S, COLOR Source, COLOR Turn);
	void Move(COLOR &Turn);
	void AllMovesSave(Position S, Position D);
	void TurnChange(COLOR& turn);
	void ReplayAllMoves(Board* B);
	void Out_Line();
	void SaveBoardInitially();
	void LoadBoardReplay();
	void SaveGame();
	void IfFunctions(Position S,COLOR Turn,Board* B);
	Piece* IfPawnPromotion(Position S, COLOR Turn, Position D);
	void FindKing(Position &K,COLOR Turn);
	bool IsCheck(COLOR Turn);
	bool CheckMate(COLOR Turn,Position S);
	void LoadGame();

	~Board();

};


#include<iostream>
#include "Board.h"
using namespace std;
int main()
{
	Board B,Temp;
	COLOR P = White;
	int opt;
	cout << "\t\nDO you want to continue with New Game(1) OR Saved Game(2)\n";
	cin >> opt;
	switch (opt)
	{
	case 1:
		B.PrintGrid();
		B.Out_Line();
		B.Play(); break;
	case 2:
		B.PrintGrid();
		B.Out_Line();
		B.LoadGame(); B.Draw(); break;
	default:
		cout << "Enter Valid option\n";
		break;
	}
	
	B.SaveBoardInitially();
	B.PrintFunctions();
	while (true)
	{		
		B.Move(P);
	}
}